﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using FYP.Models;
using System.Security.Claims;
using Microsoft.AspNetCore.Hosting;

namespace FYP.Controllers
{
    public class AdminController : Controller
    {
        
        public IActionResult Index()
        {
            return View();
        }

       
        public IActionResult AdminNavBar()
        {
            return View();
        }



        [Authorize(Roles = "Admin")]
        public IActionResult Users()
        {
            List<Users> list = DBUtl.GetList<Users>("SELECT * FROM Users");
            return View(list);
        }
     

        [HttpGet]
        public IActionResult Edit(string id)
        {
            string select = "SELECT * FROM Users WHERE User_ID='{0}'";
            List<Users> list = DBUtl.GetList<Users>(select, id);
            if (list.Count == 1)
            {
                return View(list[0]);
            }
            else
            {
                TempData["Message"] = "Cadet not found";
                TempData["MsgType"] = "warning";
                return RedirectToAction("Users");
            }
        }

        [HttpPost]
        public IActionResult Edit(Users usr)
        {
            if (!ModelState.IsValid)
            {
                ViewData["Message"] = "Invalid Input";
                ViewData["MsgType"] = "warning";
                return View("Edit");
            }
            else
            {
                string insert =
                   @"INSERT INTO Users(UserPw,  User_FirstName, User_LastName, User_Gender, User_Date_of_Birth, User_EmailAddress, User_Type, User_ContactNumber) VALUES
                 (HASHBYTES('SHA1', '{0}'), '{1}', '{2}', '{3}', '{4:yyyy-MM-dd}', '{5}', 'User', '{7}')";

                if (DBUtl.ExecSQL(insert, 
                                          usr.User_Pw,
                                          usr.User_FirstName,
                                          usr.User_LastName,
                                          usr.User_Gender,
                                          usr.User_Date_of_Birth,
                                          usr.User_EmailAddress,
                                           usr.User_Type,
                                          usr.User_ContactNumber) == 1) 
                {
                    TempData["Message"] = "User profile is Updated";
                    TempData["MsgType"] = "success";
                }
                else
                {
                    TempData["Message"] = DBUtl.DB_Message;
                    TempData["MsgType"] = "danger";
                }
                return RedirectToAction("Users");
            }
        }


       
        

        public IActionResult UploadFile()
        {
            return View();
        }
        //IformFile form variable
        public IActionResult UploadFilePost(IFormFile file)
        {
            if (file == null)
            {
                ViewData["Message"] = "Please select File to upload";
                ViewData["MsgType"] = "warning";
                return View("UploadFile");
            }

            string fname = DoPhotoUpload(file);
            ViewData["File"] = fname;
            ViewData["Message"] = "File successfully uploaded";
            ViewData["MsgType"] = "success";

            return View("UploadFile");
        }

        private void UploadFile(IFormFile ufile, string fname)
        {
            string fullpath = Path.Combine(_env.WebRootPath, fname);
            using (var fileStream = new FileStream(fullpath, FileMode.Create))
            {
                ufile.CopyToAsync(fileStream);
            }
        }

        private IWebHostEnvironment _env;
        public AdminController(IWebHostEnvironment environment)
        {
            _env = environment;
        }

        private string DoPhotoUpload(IFormFile photo)
        {
            string fext = Path.GetExtension(photo.FileName);
            string uname = Guid.NewGuid().ToString();
            string fname = uname + fext;
            string fullpath = Path.Combine(_env.WebRootPath, "Images/" + fname);
            FileStream fs = new FileStream(fullpath, FileMode.Create);
            photo.CopyTo(fs);
            fs.Close();
            return fname;
        }

        
        [Authorize(Roles = "Admin")]
        public IActionResult Delete(int id)
        {
            string User_ID = User.FindFirst(ClaimTypes.NameIdentifier).Value;

            string sql = @"SELECT * FROM Users 
                         WHERE User_ID='{0}'";

            string select = String.Format(sql, id, User_ID);
            DataTable ds = DBUtl.GetTable(select);
            if (ds.Rows.Count != 1)
            {
                TempData["Message"] = "Users Record does not exist";
                TempData["MsgType"] = "warning";
            }
            else
            {


                int res = DBUtl.ExecSQL(String.Format("DELETE FROM Users WHERE User_ID={0}", id));
                if (res == 1)
                {
                    TempData["Message"] = "User Record Deleted";
                    TempData["MsgType"] = "success";
                }
                else
                {
                    TempData["Message"] = DBUtl.DB_Message;
                    TempData["MsgType"] = "danger";
                }
            }
            return RedirectToAction("Index", "Users");
        }

        [HttpGet]
        //[Authorize(Roles = "manager")]
        public IActionResult EditMyAccount(String id)
        {
            // TODO: L13 Task 08 - Show form with values for update

            // Get the record from the database using the id
            string usersSql = @"SELECT User_Pw, User_FirstName, User_LastName,
                            User_Gender, User_EmailAddress, 
                            User_ContactNumber
                                           FROM Users
                                          WHERE User_ID = '{0}'";
            // List<Attendance> lstattendance = DBUtl.GetList<Attendance>(attendanceSql, id);
            string select = String.Format(usersSql, id);
            DataTable dt = DBUtl.GetTable(select);
            // If the record is found, pass the model to the View
            if (dt.Rows.Count == 1)
            {
                Users user = new Users
                {
                    
                   User_Pw = dt.Rows[0]["User_Pw"].ToString(),
                    User_FirstName = dt.Rows[0]["User_FirstName"].ToString(),
                    User_LastName = dt.Rows[0]["User_LastName"].ToString(),
                    User_Gender = dt.Rows[0]["User_Gender"].ToString(),
                    
                    User_EmailAddress = dt.Rows[0]["User_EmailAddress"].ToString(),
                    User_ContactNumber = (int)dt.Rows[0]["User_ContactNumber"],
                };
                return View(user);
            }
            return View();
        }

        [HttpPost]
        //[Authorize(Roles = "manager")]
        public IActionResult EditMyAccount(Users user)
        // TODO: L13 Task 09 - Update database table 
        // Check the state of the model ((Ref Week 9). 

        // Write the SQL statement

        // Execute the SQL statement in a secure manner

        // Check the result and branch
        // If successful set a TempData success Message and MsgType
        // If unsuccessful, set a TempData message that equals the DBUtl error message

        // Call the action ListMovies to show the result of the update
        {
            if (!ModelState.IsValid)
            {
                ViewData["Message"] = "Invalid Input";
                ViewData["MsgType"] = "warning";
                return View("EditMyAccount");
            }
            else
            {
                string update =
                   @"UPDATE Users
                        SET User_Pw = '{1}', User_FirstName= '{2}', User_LastName='{3}',
                            User_Gender='{4}', User_EmailAddress = '{5}', 
                            User_ContactNumber = {6}
                        WHERE User_ID='{0}'";


                if (DBUtl.ExecSQL(update, user.User_ID,
                                          user.User_Pw,
                                          user.User_FirstName,
                                          user.User_LastName,
                                          user.User_Gender,
                                          
                                          user.User_EmailAddress,
                                          user.User_ContactNumber) == 1)
                {
                    TempData["Message"] = "Attendance Updated";
                    TempData["MsgType"] = "success";
                }
                else
                {
                    TempData["Message"] = DBUtl.DB_Message;
                    TempData["MsgType"] = "danger";
                }
                return RedirectToAction("Index", "Users");
            }

        }
    }
}