﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using FYP.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace FYP.Controllers
{
    public class Form1Controller : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        [AllowAnonymous]
        public IActionResult Submit()
       {
            return View("Feedback");

        }


        [AllowAnonymous]
        public IActionResult ThankYouFB()
        {
            return View();

        }

        public IActionResult FeedbackList()
        {
                string FeedbackSql = "SELECT User_Name, User_EmailAddress, Eventid, Event_effectiveness, interest, Event_Takeaway, Event_Improvement, Additional_Comment FROM Feedback";
                DataTable dt = DBUtl.GetTable(FeedbackSql);
                return View(dt.Rows);
        }

        [AllowAnonymous]
        [HttpPost]
        public IActionResult Submit(Feedback fb)

        {
            if (!ModelState.IsValid)
            {
                ViewData["Message"] = "Fields are mandatory";
                ViewData["MsgType"] = "warning";
                return View("Feedback");
            }
            else
            {
                string insert =
                  @"INSERT INTO Feedback(User_Name, User_EmailAddress,Eventid,Event_effectiveness,interest,Event_Takeaway,Event_Improvement,Additional_Comment) 
                    VALUES('{0}','{1}',{2},'{3}','{4}','{5}','{6}','{7}')";
                if (DBUtl.ExecSQL(insert, fb.User_Name, fb.User_EmailAddress, fb.Eventid, fb.Event_effectiveness, fb.interest, fb.Event_Takeaway, fb.Event_Improvement, fb.Additional_Comment) == 1)
                {
                    string template = @"Hi {0},<br/><br/>
                               Thank you for your feedback! ";
                    string title = "Feedback Successul";
                    string message = String.Format(template, fb.User_Name, fb.User_EmailAddress, fb.Eventid, fb.Event_effectiveness, fb.interest, fb.Event_Takeaway, fb.Event_Improvement, fb.Additional_Comment);
                    string result;
                    if (EmailUtl.SendEmail(fb.User_EmailAddress, title, message, out result))
                    {
                        ViewData["Message"] = "Feedback sucessfully posted";
                        ViewData["MsgType"] = "success";
                    }
                    else
                    {
                        ViewData["Message"] = result;
                        ViewData["MsgType"] = "warning";
                    }
                }
                else
                {
                    ViewData["Message"] = DBUtl.DB_Message;
                    ViewData["MsgType"] = "danger";
                }
                return View("ThankYouFB");
            }

        }
    }
}
