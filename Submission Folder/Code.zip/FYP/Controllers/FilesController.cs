﻿using System;
using System.IO;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Generic;
using FYP.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using System.Security.Claims;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Hosting;

namespace FYP.Controllers
{
    public class FilesController : Controller
    {
        
        [HttpGet]
        public IActionResult Create()
        {
            ViewData["Files"] = GetListEvents();
            return View();
        }

        [HttpPost]
        public IActionResult Create(FileUpload cdd, IFormFile photo)
        {
            if (!ModelState.IsValid)
            {
                ViewData["Files"] = GetListEvents();

                ViewData["Message"] = "Invalid Input";
                ViewData["MsgType"] = "warning";
                return View(cdd);
            }
            else
            {
                cdd.Picture = Path.GetFileName(photo.FileName);
                string fname = "files/" + cdd.Picture;
                UploadFile(photo, fname);

                string insert = @"INSERT Upload (Picture, Eventid) 
                           VALUES('{0}',{1})";

                

                if (DBUtl.ExecSQL(insert, cdd.Picture, cdd.Eventid) == 1)
                {
                    TempData["Message"] = $"File #{cdd.Picture} uploaded Successfully";
                    TempData["MsgType"] = "success";
                    return RedirectToAction("ListFiles");
                }
                else
                {
                    ViewData["Message"] = DBUtl.DB_Message;
                    ViewData["MsgType"] = "danger";
                    return View(cdd);
                }
            }
        }

        private void UploadFile(IFormFile ufile, string fname)
        {
            string fullpath = Path.Combine(_env.WebRootPath, fname);
            using (var fileStream = new FileStream(fullpath, FileMode.Create))
            {
                ufile.CopyToAsync(fileStream);
            }
        }

       
        public IActionResult ListFiles()
        {

            // Get a list of all movies from the database
            List<FileUpload> materials = DBUtl.GetList<FileUpload>(
                  @"SELECT * FROM Upload, Events 
                  WHERE Upload.Eventid = Events.Eventid
                      
                   ");
            return View(materials);

        }

        public IActionResult FileDetails(int id)
        {
            string select =
           @"SELECT *
                    
                FROM Upload, Events 
                  WHERE Upload.Eventid = Events.Eventid
                    
                 AND Upload.Eventid={0}
                 ";
            List<FileUpload> lst = DBUtl.GetList<FileUpload>(select, id);
            return View("FileDetails",lst);


          

        }


        
        public IActionResult DeleteFile(int id)
        {
            string select = @"SELECT * FROM Upload 
                              WHERE FileId ={0}";
            DataTable ds = DBUtl.GetTable(select, id);
            if (ds.Rows.Count != 1)
            {
                TempData["Message"] = "File record no longer exists.";
                TempData["MsgType"] = "warning";
            }
            else
            {
                string delete = "DELETE FROM Upload WHERE FileId={0}";
                int res = DBUtl.ExecSQL(delete, id);
                if (res == 1)
                {
                    TempData["Message"] = "File Deleted";
                    TempData["MsgType"] = "success";
                }
                else
                {
                    TempData["Message"] = DBUtl.DB_Message;
                    TempData["MsgType"] = "danger";
                }
            }
            return RedirectToAction("ListFiles");
        }


        // private string DoPhotoUpload(IFormFile photo)
        //{
        //string fext = Path.GetExtension(photo.FileName);
        //string uname = Guid.NewGuid().ToString();
        //string fname = uname + fext;
        //string fullpath = Path.Combine(_env.WebRootPath, "files/" + fname);
        //using (FileStream fs = new FileStream(fullpath, FileMode.Create))
        // {
        //photo.CopyTo(fs);
        //}
        //return fname;
        //}

        [HttpGet]
       
        public IActionResult EditFile(string id )
        {
            // TODO: L13 Task 08 - Show form with values for update
            // To start this TASK, delete 3 lines in this method with "REMOVE THIS LINE"


            // Get the record from the database using the id
            string fileSql = @"SELECT FileId , Picture, Events.Eventid     
                               FROM Upload, Events
                              WHERE Upload.Eventid = Events.Eventid
                                AND Upload.FileId  = '{0}'";
            List<FileUpload> lstFile = DBUtl.GetList<FileUpload>(fileSql, id);

            // If the record is found, pass the model to the View
            if (lstFile.Count == 1)
            {
                ViewData["Files"] = GetListEvents();
                return View(lstFile[0]);
            }
            else
            // Otherwise redirect to the movie list page
            {
                TempData["Message"] = "File not found.";
                TempData["MsgType"] = "warning";
                return RedirectToAction("ListFiles");
            }


        }

        [HttpPost]
       
        public IActionResult EditFile(FileUpload file )
        {
            ModelState.Remove("Photo");
            if (!ModelState.IsValid)
            {
                ViewData["Files"] = GetListEvents();
                ViewData["Message"] = "Invalid Input";
                ViewData["MsgType"] = "warning";
                return View("EditFile");
            }



            string update = @"UPDATE Upload
                                SET Eventid={1}
                                WHERE FileId={0}";
            int result = DBUtl.ExecSQL(update, file.FileId, file.Eventid);

            if (result == 1)
            {
                TempData["Message"] = "File Updated";
                TempData["MsgType"] = "success";
            }
            else
            {
                TempData["Message"] = DBUtl.DB_Message;
                TempData["MsgType"] = "danger";
            }
            return RedirectToAction("ListFiles");
        }

        private IWebHostEnvironment _env;
        public FilesController(IWebHostEnvironment environment)
        {
            _env = environment;
        }

        private List<Events> GetListEvents()
        {
            // Get a list of all events from the database
            string eventSql = @"SELECT Eventid , Eventname  
                                FROM Events ";
            List<Events> lstEvent = DBUtl.GetList<Events>(eventSql);
            return lstEvent;
        }
    }
}
