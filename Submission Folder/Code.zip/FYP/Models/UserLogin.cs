﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace FYP.Models
{
    public class UserLogin
    {
        [Required(ErrorMessage = "Please enter Email Address ")]
        public string User_EmailAddress { get; set; }

        [Required(ErrorMessage = "Please enter Password")]
        [DataType(DataType.Password)]
        public string User_Pw { get; set; }

        public bool RememberMe { get; set; }
        public DateTime LastLogin { get; set; }
    }
}