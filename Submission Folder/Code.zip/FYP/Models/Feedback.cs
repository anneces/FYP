﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.ComponentModel.DataAnnotations;


namespace FYP.Models
{
    public class Feedback
    {
        [Required(ErrorMessage = "Please enter your Name")]
        public string User_Name { get; set; }

        [Required(ErrorMessage = "Please enter your Email Address")]
        [EmailAddress(ErrorMessage = "Invalid Email")]
        public string User_EmailAddress { get; set; }

        [Required(ErrorMessage = "Please enter the Event ID")]
        public int Eventid { get; set; }

        [Required]
        public string Event_effectiveness { get; set; }

        [Required]
        public string interest { get; set; }

        [Required(ErrorMessage = "This is a mandatory field")]
        public string Event_Takeaway { get; set; }

        [Required(ErrorMessage = "This is a mandatory field")]
        public string Event_Improvement { get; set; }

        public string Additional_Comment { get; set; }
    }
}
