﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace FYP.Models
{
    public class Users
    {
       
        // [Remote(action: "VerifyUserID", controller: "User")]
        public int User_ID { get; set; }

        [Required(ErrorMessage = "Please enter Password")]
        [StringLength(50, MinimumLength = 8, ErrorMessage = "Password must be 8 characters")]
        public string User_Pw { get; set; }

        [Required(ErrorMessage = "Please enter First Name")]
        public string User_FirstName { get; set; }

        [Required(ErrorMessage = "Please enter Last Name")]
        public string User_LastName { get; set; }

        [Required(ErrorMessage = "Please enter Gender")]
        public string User_Gender { get; set; }

        [Required(ErrorMessage = "Please enter Date of Birth")]
        [DataType(DataType.Date)]
        public DateTime User_Date_of_Birth { get; set; }

        [Required(ErrorMessage = "Please enter Email Address")]
        [EmailAddress(ErrorMessage = "Invalid Email")]
        public string User_EmailAddress { get; set; }

     
        public string User_Type { get; set; }

        [Required(ErrorMessage = "Please enter Contact Number")]
        public int User_ContactNumber { get; set; }

       

       

        public object PicFile { get; internal set; }

     /*   public Users(
            int User_ID,
            string User_Pw,
            int User_Type,
            string User_FirstName,
            string User_LastName,
            string User_Gender,
            DateTime User_Date_of_Birth,
            string User_EmailAddress,
            string User_ContactNumber
           

            )
        {
            User_ID = User_ID;
            User_Pw = User_Pw;
            User_FirstName = User_FirstName;
            User_LastName = User_LastName;
            User_Gender = User_Gender;
            User_EmailAddress = User_EmailAddress;
            User_Date_of_Birth = User_Date_of_Birth;
            User_Type = User_Type;
            User_ContactNumber = User_ContactNumber;
           

        }*/

    }


}
